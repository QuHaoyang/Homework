package com.example.hw2.recycler;


public class TestData {

    String title;
    String hot;

    public TestData(String title, String hot) {
        this.title = title;
        this.hot = hot;
    }
}
